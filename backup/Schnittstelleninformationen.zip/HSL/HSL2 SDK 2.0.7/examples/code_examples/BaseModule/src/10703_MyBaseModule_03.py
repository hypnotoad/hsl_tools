# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class MyBaseModule_0310703(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_VALUE_1=1
        self.PIN_I_VALUE_2=2
        self.PIN_O_RESULT=1
        self.PIN_O_ERROR=2
        self.REM_VALUE_1=1
        self.REM_VALUE_2=2
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    tmp_result = 0

    def on_init(self):
        self.REM_VALUE_1 = 0.0
        self.REM_VALUE_2 = 0.0

    def on_input_value(self, index, value):
        if index == 1:
            self.REM_VALUE_1 = value
        else:
            self.REM_VALUE_2 = value

        self.calc_result()

    def calc_result(self):
        try:
            tmp_result = self.REM_VALUE_1 / self.REM_VALUE_2
            self._set_output_value(self.PIN_O_RESULT, tmp_result)
        except ZeroDivisionError:
            self._set_output_value(self.PIN_O_ERROR, 1.0)
