# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class MyBaseModule_0110701(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_LOCK=1
        self.PIN_I_SIGNAL=2
        self.PIN_O_OUTPUT=1
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        self.is_locked = True

    def on_input_value(self, index, value):
        if index == self.PIN_I_LOCK:
            self.is_locked = value != 0

        else:
            if not self.is_locked:
                self._set_output_value(self.PIN_O_OUTPUT, value)
