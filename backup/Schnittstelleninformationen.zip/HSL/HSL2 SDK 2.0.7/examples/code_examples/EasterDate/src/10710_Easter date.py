# coding: iso-8859-15

import datetime
import date_calc.easter #can be found in libs/date_calc

##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class EasterDate10710(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_I1_TRIGGER=1
        self.PIN_O_O1_EASTER_DATE=1
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        pass

    def on_input_value(self, index, value):
        current_year = datetime.date.today().year
        easter_date=date_calc.easter.calc_easter(current_year)
        self._set_output_value(self.PIN_O_O1_EASTER_DATE, easter_date)
