# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class MyIntervaltimer10709(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_SWITCH=1
        self.PIN_I_INTERVAL=2
        self.PIN_O_SIGNAL=1
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        self.interval = None

    def on_input_value(self, index, value):
        if index == self.PIN_I_SWITCH:
            if value == 1:
                if self.interval == None:
                    self.interval = self.FRAMEWORK.create_interval()
                else:
                    self.interval.stop()

                self.interval.set_interval(self._get_input_value(self.PIN_I_INTERVAL)*1000, self.on_interval)
                self.interval.start()
            else:
                self.interval.stop()

    def on_interval(self):
        self._set_output_value(self.PIN_O_SIGNAL, 1.0)
