# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class Binary_Trigger10700(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_INPUT=1
        self.PIN_O_NOT_EQUAL_TO_ZERO=1
        self.PIN_O_EQUAL_TO_ZERO=2
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        pass

    def on_input_value(self, index, value):
      if self._get_input_value(index) != 0:
          self._set_output_value(self.PIN_O_NOT_EQUAL_TO_ZERO, 1)
      else:
          self._set_output_value(self.PIN_O_EQUAL_TO_ZERO, 1)
