(function($) {
    // TODO: make the node ID configurable
    var treeNode = $('#jsdoc-toc-nav');

    // initialize the tree
    treeNode.tree({
        autoEscape: false,
        closedIcon: '&#x21e2;',
        data: [{"label":"<a href=\"HomeServerConnector.html\">HomeServerConnector</a>","id":"HomeServerConnector","children":[]},{"label":"<a href=\"HomeServerConnector._CameraArchive.html\">_CameraArchive</a>","id":"HomeServerConnector._CameraArchive","children":[]},{"label":"<a href=\"HomeServerConnector._CameraPicture.html\">_CameraPicture</a>","id":"HomeServerConnector._CameraPicture","children":[]},{"label":"<a href=\"HomeServerConnector._CommunicationObject.html\">_CommunicationObject</a>","id":"HomeServerConnector._CommunicationObject","children":[]},{"label":"<a href=\"HomeServerConnector._Connection.html\">_Connection</a>","id":"HomeServerConnector._Connection","children":[]},{"label":"<a href=\"HomeServerConnector._DataArchive.html\">_DataArchive</a>","id":"HomeServerConnector._DataArchive","children":[]},{"label":"<a href=\"HomeServerConnector._MessageArchive.html\">_MessageArchive</a>","id":"HomeServerConnector._MessageArchive","children":[]},{"label":"<a href=\"HomeServerConnector._Scene.html\">_Scene</a>","id":"HomeServerConnector._Scene","children":[]},{"label":"<a href=\"HomeServerConnector._Sequence.html\">_Sequence</a>","id":"HomeServerConnector._Sequence","children":[]},{"label":"<a href=\"HomeServerConnector._UniversalTimer.html\">_UniversalTimer</a>","id":"HomeServerConnector._UniversalTimer","children":[]},{"label":"<a href=\"HomeServerConnector._VacationCalendar.html\">_VacationCalendar</a>","id":"HomeServerConnector._VacationCalendar","children":[]}],
        openedIcon: ' &#x21e3;',
        saveState: true,
        useContextMenu: false
    });

    // add event handlers
    // TODO
})(jQuery);
