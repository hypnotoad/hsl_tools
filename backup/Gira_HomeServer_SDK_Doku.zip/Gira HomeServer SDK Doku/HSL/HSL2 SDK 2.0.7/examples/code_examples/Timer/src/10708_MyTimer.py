# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class MyTimer10708(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_NUM_VALUE=1
        self.PIN_I_ALPHA_VALUE=2
        self.PIN_I_DELAY=3
        self.PIN_I_STOP=4
        self.PIN_O_NUM_VALUE=1
        self.PIN_O_ALPHA_VALUE=2
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        self.timer = None

    def on_input_value(self, index, value):
        if index in [self.PIN_I_NUM_VALUE, self.PIN_I_ALPHA_VALUE] :
            if self.timer == None:
                self.timer = self.FRAMEWORK.create_timer()
            else:
                self.timer.stop()

            self.timer.set_timer(self._get_input_value(self.PIN_I_DELAY)*1000, self.on_timer_timeout, (index, value))
            self.timer.start()

        elif index == self.PIN_I_STOP and value == 1:
            self.timer.stop()

    def on_timer_timeout(self, index, value):
        self._set_output_value(index, value)

