# coding: UTF-8
##!!!!##################################################################################################
#### Own written code can be placed above this commentblock . Do not change or delete commentblock! ####
########################################################################################################
##** Code created by generator - DO NOT CHANGE! **##

class MyBaseModule_0210702(hsl20_4.BaseModule):

    def __init__(self, homeserver_context):
        hsl20_4.BaseModule.__init__(self, homeserver_context, "hsl20_4_fw_examples")
        self.FRAMEWORK = self._get_framework()
        self.LOGGER = self._get_logger(hsl20_4.LOGGING_NONE,())
        self.PIN_I_INPUT=1
        self.PIN_O_OUTPUT=1
        self.REM_COUNTER=1
        self.FRAMEWORK._run_in_context_thread(self.on_init)

########################################################################################################
#### Own written code can be placed after this commentblock . Do not change or delete commentblock! ####
###################################################################################################!!!##

    def on_init(self):
        self.DEBUG = self.FRAMEWORK.create_debug_section()
        self.DEBUG.set_value("INIT", "ERR")
        self.result = 0.0

    def on_input_value(self, index, value):
        try:
            self.result = float(self._get_remanent(self.REM_COUNTER))
            self.DEBUG.set_value("INIT", self.result)
        except:
            self.result = 0.0

        self.result += 1.0
        self._set_remanent(self.REM_COUNTER, str(self.result))
        self._set_output_value(self.PIN_O_OUTPUT, self.result)
        self.DEBUG.set_value("COUNTER", self.result)
        self.DEBUG.increase_counter_field("TELEGRAMS")
